from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from .form import UserRegistration

# Create your views here.

def index(request):
    # return HttpResponse("<h1>Hello World</h1>")
    return render(request, 'index.html')

def properties(request):
    return render(request, 'properties.html')

def property_details(request):
    return render(request, 'property-details.html')

def contact(request):
    return render(request, 'contact.html')

def UserLogin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('MainPage')
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
        
    return render(request, 'login.html')

# def UserRegistration(request):
#     if request.method == 'POST':
#         first_name = request.POST.get('first_name')
#         last_name = request.POST.get('last_name')
#         email = request.POST.get('email')
#         password = request.POST.get('password')

#         return redirect('loginPage')  # Redirect to login page after registration

#     return render(request, 'registration.html')  # Render registration form

def UserRegistrationView(request):
    data = UserRegistration(request.POST)
    return render(request, 'registration.html', {'data': data})  # Render registration form