from django.db import models

# Create your models here.
class UseProfile(models.Model):
    first_name = models.CharField(max_length=20)
    email = models.EmailField(max_length=50)
    phone = models.CharField(max_length=15)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    gender = models.CharField(max_length=10, choices = [
        ("M","male"),
        ("F","female"),
    ])
    # date_of_birth = models.DateField()
    # age = models.IntegerField()
    # Profile = models.ImageField("User/Images")
    # bio = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=[
        ("active", "Active"),
        ("inactive", "Inactive"),
        ("banned", "Banned"),
    ], default="active")
    # Document = models.FileField("Document/Images")
    # created_at = models.DateTimeField(auto_now_add=False)
    # website_name = models.CharField(max_length=100, blank=True, null=True)
    # website_url = models.URLField(max_length=200, blank=True, null=True)    

    def __str__(self):
        return self.first_name


class room(models.Model):
    user = models.ForeignKey(UseProfile, on_delete=models.CASCADE, related_name='rooms')
    room_number = models.CharField(max_length=20, unique=True)
    
    def __str__(self):
        return self.room_number

  