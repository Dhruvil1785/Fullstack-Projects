from django.contrib import admin

from home.models import UseProfile
from home.models import room

# admin.site.register(UseProfile)
admin.site.register(room)

class UseProfileAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'email', 'phone', 'address']
    search_fields = ['email']
    list_filter = ['status']
    list_per_page = 10

admin.site.register(UseProfile, UseProfileAdmin)
